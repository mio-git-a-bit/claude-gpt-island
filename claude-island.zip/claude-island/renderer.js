(function () {
  const $ = (id) => document.getElementById(id);
  const island = $('island');
  const C_GAUGE = 2 * Math.PI * 40; // gauge ring, r=40
  const C_MARK = 2 * Math.PI * 38;  // collapsed mark ring, r=38

  // ---------- zoom styles (switch them from the tray menu). Only the size of the tile animates. ----------
  const STYLES = {
    quick:   { openMs: 150, closeMs: 130, ease: 'cubic-bezier(0.2, 0, 0, 1)' },
    smooth:  { openMs: 300, closeMs: 240, ease: 'cubic-bezier(0.22, 1, 0.36, 1)' },
    instant: { openMs: 0,   closeMs: 0,   ease: 'linear' }
  };
  function applyStyle(name) {
    const st = STYLES[name] || STYLES.quick;
    const s = island.style;
    s.setProperty('--dur-open', st.openMs + 'ms');
    s.setProperty('--dur-close', st.closeMs + 'ms');
    s.setProperty('--ease', st.ease);
  }

  let latest = null;
  let target = null;
  let lastPayload = null;
  let mode = loadMode(); // '5h' | '7d'

  function loadMode() {
    try { return localStorage.getItem('mode') === '7d' ? '7d' : '5h'; } catch (_) { return '5h'; }
  }
  function saveMode() {
    try { localStorage.setItem('mode', mode); } catch (_) {}
  }

  const clamp = (n, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));

  // everything is drawn straight at its final value: no sweeping, no counting
  function paint() {
    const v = target === null ? 0 : target;
    const g = $('gaugeFill');
    const m = $('markFill');
    g.style.strokeDashoffset = C_GAUGE * (1 - v / 100);
    m.style.strokeDashoffset = C_MARK * (1 - v / 100);
    const visible = v > 0.4 ? '1' : '0'; // avoid a round-cap dot at 0%
    g.style.opacity = visible;
    m.style.opacity = visible;
    $('num').textContent = target === null ? '--' : String(Math.round(v));
    $('lab').textContent = labelText(lastPayload);
    island.classList.toggle('low', target !== null && target <= 10);
  }

  function remainingFor(data) {
    if (!data) return null;
    const win = mode === '5h' ? data.five_hour : data.seven_day;
    if (!win || typeof win.utilization !== 'number') return null;
    return clamp(100 - Math.round(win.utilization));
  }

  function labelText(payload) {
    if (target === null && payload && payload.status && payload.status !== 'ok') {
      return { auth: 'SIGN IN', offline: 'OFFLINE', rate: 'RETRY' }[payload.status] || 'ERROR';
    }
    return (mode === '5h' ? '5H' : '7D') + ' LEFT';
  }

  function onUsage(payload) {
    lastPayload = payload;
    const good = payload.status === 'ok' ? payload : payload.last || latest;
    if (good) latest = good;
    target = remainingFor(latest && latest.data);
    island.classList.toggle('stale', payload.status !== 'ok' && target !== null);
    paint();
  }

  // hover is decided by the main process from the real cursor position
  window.island.onHover((hovering) => {
    island.classList.toggle('expanded', hovering);
    island.classList.toggle('collapsed', !hovering);
  });

  // click: switch between the 5-hour session and the weekly limit
  document.addEventListener('click', () => {
    mode = mode === '5h' ? '7d' : '5h';
    saveMode();
    target = remainingFor(latest && latest.data);
    paint();
  });

  window.island.onLogo((dataUrl) => {
    const img = $('logo');
    img.onload = () => {
      img.hidden = false;
      $('markSvg').setAttribute('hidden', '');
    };
    img.src = dataUrl;
  });

  window.island.onVisibility((visible) => {
    island.classList.toggle('boot', !visible);
    if (!visible) {
      island.classList.remove('expanded');
      island.classList.add('collapsed');
    }
  });

  window.island.onStyle(applyStyle);
  window.island.onUsage(onUsage);

  applyStyle('quick');
  paint();
  requestAnimationFrame(() => {
    setTimeout(() => island.classList.remove('boot'), 250);
  });
})();
