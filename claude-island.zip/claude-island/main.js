const { app, BrowserWindow, Tray, Menu, ipcMain, screen, nativeImage, shell, globalShortcut } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

// ---------- settings ----------
const POLL_MS = 5 * 60 * 1000; // Anthropic rate-limits the usage endpoint, so don't poll faster
const HOVER_REFRESH_MIN_MS = 90 * 1000; // hovering may trigger a refresh, but never more often than this
const WIN_W = 150;
const WIN_H = 150;
const TILE = 58;                 // collapsed tile size
const CARD = 98;                 // expanded card size
const HOVER_POLL_MS = 40;        // how often the real cursor position is checked
const HOVER_SLACK = 3;
const DEFAULT_OFFSET_Y = 100;    // distance from the top of the work area
const NUDGE = 20;                // tray "Move up / Move down" step
const SHORTCUT = 'CommandOrControl+Alt+Shift+Y';

let settings = { launchAtLogin: false, offsetY: DEFAULT_OFFSET_Y, anim: 'quick' };
let visible = true;
let shortcutOk = false;
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function loadSettings() {
  try {
    settings = { ...settings, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch (_) {}
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (_) {}
}

// ---------- optional custom logo ----------
// Put claude.webp (or claude.png / logo.png ...) in the app folder or in %APPDATA%\claude-island\
function findLogo() {
  const names = [
    'claude.webp', 'claude.png', 'claude.svg', 'claude.jpg', 'claude.jpeg',
    'logo.webp', 'logo.png', 'logo.svg', 'logo.jpg', 'logo.jpeg'
  ];
  const mime = { png: 'image/png', svg: 'image/svg+xml', webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
  const dirs = [app.getPath('userData'), __dirname];
  for (const dir of dirs) {
    for (const name of names) {
      try {
        const file = path.join(dir, name);
        const stat = fs.statSync(file);
        if (!stat.isFile() || stat.size > 2 * 1024 * 1024) continue;
        const ext = name.split('.').pop();
        return `data:${mime[ext]};base64,${fs.readFileSync(file).toString('base64')}`;
      } catch (_) {}
    }
  }
  return null;
}

// ---------- credentials ----------
function credentialPaths() {
  const paths = [];
  if (process.env.CLAUDE_CONFIG_DIR) {
    paths.push(path.join(process.env.CLAUDE_CONFIG_DIR, '.credentials.json'));
  }
  paths.push(path.join(os.homedir(), '.claude', '.credentials.json'));
  return paths;
}

function readToken() {
  if (process.env.CLAUDE_CODE_OAUTH_TOKEN) {
    return { token: process.env.CLAUDE_CODE_OAUTH_TOKEN };
  }
  for (const p of credentialPaths()) {
    try {
      const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
      const oauth = raw.claudeAiOauth || raw;
      if (oauth && oauth.accessToken) {
        return { token: oauth.accessToken, expiresAt: oauth.expiresAt, plan: oauth.subscriptionType };
      }
    } catch (_) {}
  }
  return null;
}

// ---------- usage fetch ----------
function fetchUsage() {
  return new Promise((resolve) => {
    const cred = readToken();
    if (!cred) return resolve({ status: 'auth', message: 'Not signed in. Run "claude" once in a terminal.' });
    if (cred.expiresAt && Number(cred.expiresAt) < Date.now()) {
      return resolve({ status: 'auth', message: 'Login expired. Open Claude Code once to refresh it.' });
    }

    const req = https.request(
      {
        hostname: 'api.anthropic.com',
        path: '/api/oauth/usage',
        method: 'GET',
        timeout: 15000,
        headers: {
          Authorization: `Bearer ${cred.token}`,
          'anthropic-beta': 'oauth-2025-04-20',
          Accept: 'application/json',
          'User-Agent': 'claude-island/1.0'
        }
      },
      (res) => {
        let body = '';
        res.on('data', (c) => (body += c));
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              return resolve({ status: 'ok', data: JSON.parse(body), plan: cred.plan, fetchedAt: Date.now() });
            } catch (_) {
              return resolve({ status: 'error', message: 'Unexpected response from Anthropic.' });
            }
          }
          if (res.statusCode === 401 || res.statusCode === 403) {
            return resolve({ status: 'auth', message: 'Login expired. Open Claude Code once to refresh it.' });
          }
          if (res.statusCode === 429) {
            return resolve({ status: 'rate', message: 'Rate limited, will retry shortly.' });
          }
          resolve({ status: 'error', message: `Request failed (${res.statusCode}).` });
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', () => resolve({ status: 'offline', message: 'Offline, will retry.' }));
    req.end();
  });
}

// ---------- window ----------
let win = null;
let tray = null;
let lastGood = null;
let lastFetch = 0;
let timer = null;

function placeWindow() {
  if (!win) return;
  // Flush against the right edge of the primary display, offsetY below the top of the work area.
  const wa = screen.getPrimaryDisplay().workArea;
  const maxY = Math.max(0, wa.height - TILE - 12);
  const off = Math.min(Math.max(Number(settings.offsetY) || 0, 0), maxY);
  win.setBounds({
    x: wa.x + wa.width - WIN_W,
    y: wa.y + off,
    width: WIN_W,
    height: WIN_H
  });
}

function nudge(dy) {
  settings.offsetY = (Number(settings.offsetY) || 0) + dy;
  saveSettings();
  placeWindow();
}

// ---------- hover: decided here from the real cursor position (DOM mouse events are unreliable on click-through windows) ----------
let hovering = false;
let leaveCount = 0;
let hoverTimer = null;

function setHover(v) {
  if (v === hovering) return;
  hovering = v;
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(!v, { forward: true });
  win.webContents.send('hover', v);
  if (v) refresh(false); // throttled
}
function resetHover() { leaveCount = 0; setHover(false); }

function pollCursor() {
  if (!win || win.isDestroyed() || !visible) return;
  const p = screen.getCursorScreenPoint();
  const b = win.getBounds();
  const lx = p.x - b.x;
  const ly = p.y - b.y;
  const size = hovering ? CARD + HOVER_SLACK : TILE;
  const inside = lx >= b.width - size && lx <= b.width + 2 && ly >= -2 && ly <= size;
  if (inside) {
    leaveCount = 0;
    setHover(true);
  } else if (hovering) {
    leaveCount += 1;
    if (leaveCount >= 3) { leaveCount = 0; setHover(false); }
  }
}

// Show or hide the island; the renderer plays the slide animation and main hides the window afterwards.
function setVisible(v) {
  if (!win || win.isDestroyed() || v === visible) return;
  visible = v;
  resetHover();
  if (v) {
    win.setAlwaysOnTop(true, 'screen-saver');
    win.showInactive();
    win.webContents.send('visibility', true);
    refresh(false);
  } else {
    win.webContents.send('visibility', false);
    setTimeout(() => {
      if (!visible && win && !win.isDestroyed()) win.hide();
    }, 600);
  }
}
const toggleVisible = () => setVisible(!visible);

function createWindow() {
  win = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: false,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true);
  win.setIgnoreMouseEvents(true, { forward: true });
  placeWindow();
  win.loadFile('index.html');
  win.once('ready-to-show', () => win.showInactive());
  win.webContents.on('did-finish-load', () => {
    resetHover();
    win.webContents.send('style', settings.anim);
    const logo = findLogo();
    if (logo) win.webContents.send('logo', logo);
    if (lastGood) win.webContents.send('usage', lastGood);
    refresh(true);
  });
}

async function refresh(force = false) {
  const now = Date.now();
  if (!force && now - lastFetch < HOVER_REFRESH_MIN_MS) return;
  lastFetch = now;
  const result = await fetchUsage();
  if (result.status === 'ok') lastGood = result;
  if (win && !win.isDestroyed()) {
    win.webContents.send('usage', result.status === 'ok' ? result : { ...result, last: lastGood });
  }
}

// Register (or remove) the app to start with Windows. Works for `npm start`, the portable exe and the installer.
function applyLoginItem(enabled) {
  const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
  const args = app.isPackaged ? [] : [app.getAppPath()];
  app.setLoginItemSettings({ openAtLogin: enabled, path: exe, args });
}

function buildTray() {
  const iconPath = path.join(__dirname, 'icon.png');
  let img = nativeImage.createFromPath(iconPath);
  if (!img.isEmpty()) img = img.resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('Claude Island');
  const menu = Menu.buildFromTemplate([
    { label: 'Refresh now', click: () => refresh(true) },
    {
      label: shortcutOk ? 'Show / hide island  (Ctrl+Alt+Shift+Y)' : 'Show / hide island  (shortcut unavailable)',
      click: toggleVisible
    },
    {
      label: 'Open / close style',
      submenu: [
        ['quick', 'Quick zoom'],
        ['smooth', 'Smooth zoom'],
        ['instant', 'Instant (no animation)']
      ].map(([id, label]) => ({
        label,
        type: 'radio',
        checked: settings.anim === id,
        click: () => {
          settings.anim = id;
          saveSettings();
          if (win && !win.isDestroyed()) win.webContents.send('style', id);
        }
      }))
    },
    { label: 'Move down', click: () => nudge(NUDGE) },
    { label: 'Move up', click: () => nudge(-NUDGE) },
    {
      label: 'Reset position',
      click: () => {
        settings.offsetY = DEFAULT_OFFSET_Y;
        saveSettings();
        placeWindow();
      }
    },
    { type: 'separator' },
    {
      label: 'Open logo folder',
      click: () => {
        const dir = app.getPath('userData');
        try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
        shell.openPath(dir);
      }
    },
    { type: 'separator' },
    {
      label: 'Start with Windows',
      type: 'checkbox',
      checked: settings.launchAtLogin,
      click: (item) => {
        settings.launchAtLogin = item.checked;
        saveSettings();
        applyLoginItem(item.checked);
      }
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]);
  tray.setContextMenu(menu);
  tray.on('click', () => refresh(true));
}

// ---------- app lifecycle ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.whenReady().then(() => {
    loadSettings();
    if (settings.launchAtLogin) applyLoginItem(true); // keep the startup entry pointing at the current exe
    shortcutOk = globalShortcut.register(SHORTCUT, toggleVisible);
    createWindow();
    buildTray();
    timer = setInterval(() => refresh(true), POLL_MS);
    hoverTimer = setInterval(pollCursor, HOVER_POLL_MS);

    screen.on('display-metrics-changed', placeWindow);
    screen.on('display-added', placeWindow);
    screen.on('display-removed', placeWindow);

    ipcMain.on('refresh', () => refresh(false));
  });

  app.on('window-all-closed', () => {});
  app.on('before-quit', () => { if (timer) clearInterval(timer); if (hoverTimer) clearInterval(hoverTimer); });
  app.on('will-quit', () => globalShortcut.unregisterAll());
}
