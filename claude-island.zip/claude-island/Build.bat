@echo off
cd /d "%~dp0"
echo Installing (first time only)...
if not exist node_modules call npm install
if not exist node_modules\electron\dist call npm install-scripts approve electron
if not exist node_modules\electron\dist node node_modules\electron\install.js
echo Building the exe...
call npm run build
echo.
echo Done. Your exe is in the "dist" folder.
start "" dist
pause
