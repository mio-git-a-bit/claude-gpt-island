# Claude Island (Windows)

A small black tile pinned to the **right edge** of your screen. It shows your Claude logo. Hover it and it grows
into an orange ring showing how much of your Claude usage you have **left**.

- Collapsed: your `claude.webp` logo (or a small orange ring mark if you haven't added the file).
- Hover: the tile zooms open and shows the ring and the number right away.
- Click: switch between the **5-hour session** and the **weekly** limit (the choice is remembered).
- **Ctrl + Alt + Shift + Y**: show or hide the island (it slides in and out). Press it again to bring it back.
- Low usage (10% left or less): the ring turns a stronger red-orange.
- Click-through everywhere outside the tile, always on top, no taskbar entry.
- Tray icon: Refresh now, Show / hide, Open / close style, Move up, Move down, Reset position, Open logo folder, Start with Windows, Quit.

## Open / close style

Right-click the tray icon, then **Open / close style**. It changes instantly and is remembered.

- **Quick zoom**, the default: the tile zooms open in about a tenth of a second.
- **Smooth zoom**: a slightly slower zoom.
- **Instant (no animation)**: no animation at all.

The usage is always shown directly: no ring sweep, no counting up, no fading. Hover is detected from the real
cursor position, so the tile can no longer get stuck open when the mouse is somewhere else.

---

## Where to put claude.webp

Name the file exactly `claude.webp` (`claude.png` and `logo.png` also work) and put it in ONE of these places, then restart the app:

1. Next to `main.js`, for example `C:\apps\claude-island\claude.webp` (when you start with `npm start`).
2. In `%APPDATA%\claude-island\`, for example `C:\Users\YourName\AppData\Roaming\claude-island\claude.webp`.
   This also works for the built exe without rebuilding. The tray menu item **Open logo folder** opens it for you.

---

## Position

The tile starts 100 px below the top of the screen. Use the tray menu **Move down** / **Move up** (20 px per click)
or **Reset position**. Your choice is saved.

---

## 1. Connect it to Claude (one time)

The app has no login screen. It reads the login that **Claude Code** saves on your PC, so you only need to
sign in to Claude Code once with your Claude account.

1. You need a **Claude Pro, Max, Team or Enterprise** account (the free plan has no Claude Code access).
2. Install Claude Code. Open **PowerShell** and run:

   ```
   irm https://claude.ai/install.ps1 | iex
   ```

3. Open a **new** PowerShell window and check it worked:

   ```
   claude --version
   ```

4. Run `claude`. A browser window opens, sign in with your Claude account and approve. When the terminal says
   `Login successful`, press Enter. You can close it after that.
5. Start Claude Island (section 2). Within a few seconds the ring shows your remaining usage.

---

## 2. Install Claude Island

You need [Node.js](https://nodejs.org) 18 or newer (LTS is fine).

1. Unzip into a permanent folder, for example `C:\apps\claude-island`.
2. If PowerShell says running scripts is disabled, run this once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`
3. In that folder run `npm install` (one time), then `npm start`.
   Or double-click `Claude Island.vbs` to start it without a console window.

**Recommended for daily use (a real exe):**

- Portable single file: `npm run build`, then run the exe in `dist\`.
- Or an installer: `npm run build:installer`, then run the setup exe in `dist\`.

If the build fails with a "cannot create symbolic link" error, turn on **Windows Developer Mode**
(Settings, System, For developers), then build again.

**Start with Windows:** right-click the tray icon and tick **Start with Windows** (do this from the built exe).

---

## 3. Update it later

There is no automatic updater. Updating means replacing the files:

1. Quit it from the tray icon.
2. Copy the new files over the old folder (keep `node_modules` and your `claude.webp`).
3. Run `npm install` only if `package.json` changed.
4. Start it again, or rebuild the exe with `npm run build` and replace your old exe.

Claude Code itself updates in the background. To force it, run `claude update`.

---

## Notes

- Data comes from Anthropic's undocumented `/api/oauth/usage` endpoint, so it could change or break.
- It refreshes every 5 minutes, and hovering can trigger a refresh at most every 90 seconds (the endpoint
  rate-limits faster polling). The tray "Refresh now" always refreshes.
- If the tile shows SIGN IN, run `claude` once so the login is renewed. The app picks it up on the next refresh.
- If Ctrl+Alt+Shift+Y does nothing, another program already uses that shortcut. The tray menu then says
  "shortcut unavailable", but the tray item still shows and hides the island.
- The app only reads your token locally and sends it to api.anthropic.com. Nothing else leaves your machine.
