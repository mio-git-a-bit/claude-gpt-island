const { app, BrowserWindow, Tray, Menu, ipcMain, screen, nativeImage, shell, globalShortcut } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

// ---------- settings ----------
const POLL_MS = 5 * 60 * 1000; // don't poll faster than this
const HOVER_REFRESH_MIN_MS = 90 * 1000; // hovering may trigger a refresh, but never more often than this
const WIN_W = 150;
const WIN_H = 150;
const TILE = 58;                 // collapsed tile size
const CARD = 98;                 // expanded card size
const HOVER_POLL_MS = 40;        // how often the real cursor position is checked
const HOVER_SLACK = 3;
const DEFAULT_OFFSET_Y = 210;    // distance from the top of the work area
const NUDGE = 20;                // tray "Move up / Move down" step
const SHORTCUT = 'CommandOrControl+Alt+Shift+G';

let settings = { launchAtLogin: false, offsetY: DEFAULT_OFFSET_Y, anim: 'quick' };
let visible = true;
let shortcutOk = false;
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function loadSettings() {
  try {
    settings = { ...settings, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch (_) {}
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (_) {}
}

// ---------- optional custom logo: gpt.png (or gpt.webp ...) in the app folder or %APPDATA%\gpt-island\ ----------
function findImage(baseName) {
  const exts = ['webp', 'png', 'svg', 'jpg', 'jpeg'];
  const mime = { png: 'image/png', svg: 'image/svg+xml', webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
  const dirs = [app.getPath('userData'), __dirname];
  for (const dir of dirs) {
    for (const ext of exts) {
      try {
        const file = path.join(dir, `${baseName}.${ext}`);
        const stat = fs.statSync(file);
        if (!stat.isFile() || stat.size > 2 * 1024 * 1024) continue;
        return `data:${mime[ext]};base64,${fs.readFileSync(file).toString('base64')}`;
      } catch (_) {}
    }
  }
  return null;
}
const findLogo = () => findImage('gpt');

// ---------- shared HTTPS helper ----------
function getJson(hostname, reqPath, headers) {
  return new Promise((resolve) => {
    const req = https.request(
      { hostname, path: reqPath, method: 'GET', timeout: 15000, headers },
      (res) => {
        let body = '';
        res.on('data', (c) => (body += c));
        res.on('end', () => resolve({ code: res.statusCode, body }));
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', () => resolve({ code: 0, body: '' }));
    req.end();
  });
}

function statusFromCode(code, authMsg) {
  if (code === 0) return { status: 'offline', message: 'Offline, will retry.' };
  if (code === 401 || code === 403) return { status: 'auth', message: authMsg };
  if (code === 429) return { status: 'rate', message: 'Rate limited, will retry shortly.' };
  return { status: 'error', message: `Request failed (${code}).` };
}

// ---------- ChatGPT (Codex usage limits, login saved by the Codex CLI) ----------
function codexAuthPath() {
  const home = process.env.CODEX_HOME || path.join(os.homedir(), '.codex');
  return path.join(home, 'auth.json');
}

function decodeJwt(token) {
  try {
    const part = String(token).split('.')[1];
    return JSON.parse(Buffer.from(part.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
  } catch (_) {
    return null;
  }
}

function readCodexToken() {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(codexAuthPath(), 'utf8'));
  } catch (_) {
    return { error: 'missing' };
  }
  const t = raw.tokens || {};
  if (!t.access_token) return { error: 'nologin' }; // for example an API-key login, which has no ChatGPT limits
  const claims = decodeJwt(t.access_token) || {};
  const idClaims = decodeJwt(t.id_token) || {};
  const accountId =
    t.account_id ||
    (claims['https://api.openai.com/auth'] || {}).chatgpt_account_id ||
    (idClaims['https://api.openai.com/auth'] || {}).chatgpt_account_id ||
    null;
  return { token: t.access_token, accountId, expMs: claims.exp ? claims.exp * 1000 : null };
}

// turn the ChatGPT payload into the same shape the Claude one has: five_hour / seven_day with utilization
function normalizeCodex(data) {
  const rl = (data && data.rate_limit) || {};
  const out = {};
  const toWin = (w) => ({
    utilization: Number(w.used_percent),
    resets_at: w.reset_at ? new Date(Number(w.reset_at) * 1000).toISOString() : null
  });
  const list = [rl.primary_window, rl.secondary_window].filter((w) => w && typeof w.used_percent === 'number');
  for (const w of list) {
    const secs = Number(w.limit_window_seconds);
    // short window (about 5 hours) vs long window (about 7 days), matched by duration
    const isShort = secs ? secs <= 36 * 3600 : w === rl.primary_window;
    if (isShort && !out.five_hour) out.five_hour = toWin(w);
    else if (!out.seven_day) out.seven_day = toWin(w);
  }
  return out;
}

async function fetchGpt() {
  const cred = readCodexToken();
  if (cred.error === 'missing') {
    return { status: 'auth', message: 'No Codex login found. Sign in to Codex with ChatGPT (see README).' };
  }
  if (cred.error) {
    return { status: 'auth', message: 'Codex is not signed in with a ChatGPT account.' };
  }
  if (cred.expMs && cred.expMs < Date.now()) {
    return { status: 'auth', message: 'ChatGPT login expired. Run "codex" once to refresh it.' };
  }
  const headers = {
    Authorization: `Bearer ${cred.token}`,
    Accept: 'application/json',
    'User-Agent': 'gpt-island/1.0'
  };
  if (cred.accountId) headers['ChatGPT-Account-Id'] = cred.accountId;
  const res = await getJson('chatgpt.com', '/backend-api/wham/usage', headers);
  if (res.code === 200) {
    try {
      const raw = JSON.parse(res.body);
      return { status: 'ok', data: normalizeCodex(raw), plan: raw.plan_type, fetchedAt: Date.now() };
    } catch (_) {
      return { status: 'error', message: 'Unexpected response from ChatGPT.' };
    }
  }
  return statusFromCode(res.code, 'ChatGPT login expired. Run "codex" once to refresh it.');
}

// ---------- window ----------
// ---------- window ----------
let win = null;
let tray = null;
let lastGood = null;
let lastFetch = 0;
let timer = null;

function placeWindow() {
  if (!win) return;
  // Flush against the right edge of the primary display, offsetY below the top of the work area.
  const wa = screen.getPrimaryDisplay().workArea;
  const maxY = Math.max(0, wa.height - TILE - 12);
  const off = Math.min(Math.max(Number(settings.offsetY) || 0, 0), maxY);
  win.setBounds({
    x: wa.x + wa.width - WIN_W,
    y: wa.y + off,
    width: WIN_W,
    height: WIN_H
  });
}

function nudge(dy) {
  settings.offsetY = (Number(settings.offsetY) || 0) + dy;
  saveSettings();
  placeWindow();
}

// ---------- hover: decided here from the real cursor position (DOM mouse events are unreliable on click-through windows) ----------
let hovering = false;
let leaveCount = 0;
let hoverTimer = null;

function setHover(v) {
  if (v === hovering) return;
  hovering = v;
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(!v, { forward: true });
  win.webContents.send('hover', v);
  if (v) refresh(false); // throttled
}
function resetHover() { leaveCount = 0; setHover(false); }

function pollCursor() {
  if (!win || win.isDestroyed() || !visible) return;
  const p = screen.getCursorScreenPoint();
  const b = win.getBounds();
  const lx = p.x - b.x;
  const ly = p.y - b.y;
  const size = hovering ? CARD + HOVER_SLACK : TILE;
  const inside = lx >= b.width - size && lx <= b.width + 2 && ly >= -2 && ly <= size;
  if (inside) {
    leaveCount = 0;
    setHover(true);
  } else if (hovering) {
    leaveCount += 1;
    if (leaveCount >= 3) { leaveCount = 0; setHover(false); }
  }
}

// Show or hide the island; the renderer plays the slide animation and main hides the window afterwards.
function setVisible(v) {
  if (!win || win.isDestroyed() || v === visible) return;
  visible = v;
  resetHover();
  if (v) {
    win.setAlwaysOnTop(true, 'screen-saver');
    win.showInactive();
    win.webContents.send('visibility', true);
    refresh(false);
  } else {
    win.webContents.send('visibility', false);
    setTimeout(() => {
      if (!visible && win && !win.isDestroyed()) win.hide();
    }, 600);
  }
}
const toggleVisible = () => setVisible(!visible);

function createWindow() {
  win = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: false,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true);
  win.setIgnoreMouseEvents(true, { forward: true });
  placeWindow();
  win.loadFile('index.html');
  win.once('ready-to-show', () => win.showInactive());
  win.webContents.on('did-finish-load', () => {
    resetHover();
    win.webContents.send('style', settings.anim);
    const logo = findLogo();
    if (logo) win.webContents.send('logo', logo);
    if (lastGood) win.webContents.send('usage', lastGood);
    refresh(true);
  });
}

async function refresh(force = false) {
  const now = Date.now();
  if (!force && now - lastFetch < HOVER_REFRESH_MIN_MS) return;
  lastFetch = now;
  const result = await fetchGpt();
  if (result.status === 'ok') lastGood = result;
  if (win && !win.isDestroyed()) {
    win.webContents.send('usage', result.status === 'ok' ? result : { ...result, last: lastGood });
  }
}

// Register (or remove) the app to start with Windows. Works for `npm start`, the portable exe and the installer.
function applyLoginItem(enabled) {
  const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
  const args = app.isPackaged ? [] : [app.getAppPath()];
  app.setLoginItemSettings({ openAtLogin: enabled, path: exe, args });
}

function buildTray() {
  const iconPath = path.join(__dirname, 'icon.png');
  let img = nativeImage.createFromPath(iconPath);
  if (!img.isEmpty()) img = img.resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('GPT Island');
  const menu = Menu.buildFromTemplate([
    { label: 'Refresh now', click: () => refresh(true) },
    {
      label: shortcutOk ? 'Show / hide island  (Ctrl+Alt+Shift+G)' : 'Show / hide island  (shortcut unavailable)',
      click: toggleVisible
    },
    {
      label: 'Open / close style',
      submenu: [
        ['quick', 'Quick zoom'],
        ['smooth', 'Smooth zoom'],
        ['instant', 'Instant (no animation)']
      ].map(([id, label]) => ({
        label,
        type: 'radio',
        checked: settings.anim === id,
        click: () => {
          settings.anim = id;
          saveSettings();
          if (win && !win.isDestroyed()) win.webContents.send('style', id);
        }
      }))
    },
    { label: 'Move down', click: () => nudge(NUDGE) },
    { label: 'Move up', click: () => nudge(-NUDGE) },
    {
      label: 'Reset position',
      click: () => {
        settings.offsetY = DEFAULT_OFFSET_Y;
        saveSettings();
        placeWindow();
      }
    },
    { type: 'separator' },
    {
      label: 'Open logo folder',
      click: () => {
        const dir = app.getPath('userData');
        try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
        shell.openPath(dir);
      }
    },
    { type: 'separator' },
    {
      label: 'Start with Windows',
      type: 'checkbox',
      checked: settings.launchAtLogin,
      click: (item) => {
        settings.launchAtLogin = item.checked;
        saveSettings();
        applyLoginItem(item.checked);
      }
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]);
  tray.setContextMenu(menu);
  tray.on('click', () => refresh(true));
}

// ---------- app lifecycle ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.whenReady().then(() => {
    loadSettings();
    if (settings.launchAtLogin) applyLoginItem(true); // keep the startup entry pointing at the current exe
    shortcutOk = globalShortcut.register(SHORTCUT, toggleVisible);
    createWindow();
    buildTray();
    timer = setInterval(() => refresh(true), POLL_MS);
    hoverTimer = setInterval(pollCursor, HOVER_POLL_MS);

    screen.on('display-metrics-changed', placeWindow);
    screen.on('display-added', placeWindow);
    screen.on('display-removed', placeWindow);

    ipcMain.on('refresh', () => refresh(false));
  });

  app.on('window-all-closed', () => {});
  app.on('before-quit', () => { if (timer) clearInterval(timer); if (hoverTimer) clearInterval(hoverTimer); });
  app.on('will-quit', () => globalShortcut.unregisterAll());
}
