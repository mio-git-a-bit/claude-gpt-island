(function () {
  const $ = (id) => document.getElementById(id);
  const island = $('island');
  const C_GAUGE = 2 * Math.PI * 40; // gauge ring, r=40
  const C_MARK = 2 * Math.PI * 38;  // collapsed mark ring, r=38
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---------- animation styles (switch them from the tray menu) ----------
  const SPRING = 'linear(0, 0.0121, 0.0451, 0.0946, 0.1566, 0.2275, 0.304, 0.3833, 0.4632, 0.5416, 0.617, 0.6882, 0.7541, 0.8143, 0.8682, 0.9158, 0.9571, 0.9921, 1.0211, 1.0446, 1.0629, 1.0766, 1.086, 1.0919, 1.0945, 1.0945, 1.0922, 1.0882, 1.0829, 1.0765, 1.0695, 1.0621, 1.0545, 1.047, 1.0397, 1.0327, 1.0262, 1.0203, 1.0149, 1.0101, 1.0059, 1.0023, 0.9993, 0.9968, 0.9948, 0.9933, 0.9922, 0.9915, 1)';
  const STYLES = {
    glide:  { openMs: 520, closeMs: 360, openEase: 'cubic-bezier(0.22, 1, 0.36, 1)', closeEase: 'cubic-bezier(0.4, 0, 0.2, 1)', gaugeDelay: 140, sweepMs: 950 },
    bouncy: { openMs: 760, closeMs: 420, openEase: SPRING, closeEase: 'cubic-bezier(0.32, 0.72, 0, 1)', gaugeDelay: 110, sweepMs: 900 },
    snappy: { openMs: 240, closeMs: 200, openEase: 'cubic-bezier(0.2, 0, 0, 1)', closeEase: 'cubic-bezier(0.4, 0, 1, 1)', gaugeDelay: 40, sweepMs: 420 }
  };
  let cur = STYLES.glide;

  function applyStyle(name) {
    cur = STYLES[name] || STYLES.glide;
    const s = island.style;
    s.setProperty('--dur-open', cur.openMs + 'ms');
    s.setProperty('--ease-open', cur.openEase);
    s.setProperty('--dur-close', cur.closeMs + 'ms');
    s.setProperty('--ease-close', cur.closeEase);
    s.setProperty('--gauge-delay', cur.gaugeDelay + 'ms');
  }

  // ---------- one state object per service ----------
  const makeState = (id) => ({
    id,
    target: null,   // remaining % for the selected window, or null when unknown
    shown: 0,       // remaining % currently drawn (animated)
    raf: 0,
    latest: null,   // last good usage payload
    payload: null,  // last payload of any kind (ok or error)
    el: {
      gauge: $('gaugeFill-' + id),
      mark: $('markFill-' + id),
      num: $('num-' + id),
      lab: $('lab-' + id),
      cell: $('cell-' + id),
      slot: $('markSvg-' + id).parentElement
    }
  });
  const S = { claude: makeState('claude'), gpt: makeState('gpt') };
  const ALL = [S.claude, S.gpt];

  let mode = loadMode();  // '5h' | '7d' (shared by both rings)

  function loadMode() {
    try { return localStorage.getItem('mode') === '7d' ? '7d' : '5h'; } catch (_) { return '5h'; }
  }
  function saveMode() {
    try { localStorage.setItem('mode', mode); } catch (_) {}
  }

  // ---------- drawing ----------
  const clamp = (n, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));
  const easeInOutCubic = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
  const easeOutCubic = (k) => 1 - Math.pow(1 - k, 3);

  function paintRings(p, v) {
    p.el.gauge.style.strokeDashoffset = C_GAUGE * (1 - v / 100);
    p.el.mark.style.strokeDashoffset = C_MARK * (1 - v / 100);
    const visible = v > 0.4 ? '1' : '0'; // avoid a round-cap dot at 0%
    p.el.gauge.style.opacity = visible;
    p.el.mark.style.opacity = visible;
    p.el.num.textContent = p.target === null ? '--' : String(Math.round(v));
  }

  // animate the drawn value; delay lets the tile finish opening before the ring starts to sweep
  function tweenTo(p, to, duration, delay, ease) {
    cancelAnimationFrame(p.raf);
    if (reduceMotion || duration <= 0) {
      p.shown = to;
      paintRings(p, p.shown);
      return;
    }
    const from = p.shown;
    const t0 = performance.now() + (delay || 0);
    const fn = ease || easeInOutCubic;
    const step = (now) => {
      const k = Math.min(1, Math.max(0, (now - t0) / duration));
      p.shown = from + (to - from) * fn(k);
      paintRings(p, p.shown);
      if (now - t0 < duration) p.raf = requestAnimationFrame(step);
    };
    p.raf = requestAnimationFrame(step);
  }

  function remainingFor(p) {
    const data = p.latest && p.latest.data;
    if (!data) return null;
    const win = mode === '5h' ? data.five_hour : data.seven_day;
    if (!win || typeof win.utilization !== 'number') return null;
    return clamp(100 - Math.round(win.utilization));
  }

  function labelText(p) {
    const pl = p.payload;
    if (p.target === null && pl && pl.status && pl.status !== 'ok') {
      return { auth: 'SIGN IN', offline: 'OFFLINE', rate: 'RETRY' }[pl.status] || 'ERROR';
    }
    return (mode === '5h' ? '5H' : '7D') + ' LEFT';
  }

  function setLabel(p, text, animate) {
    const lab = p.el.lab;
    if (lab.textContent === text) return;
    if (!animate || reduceMotion) { lab.textContent = text; return; }
    lab.classList.add('swap');
    setTimeout(() => { lab.textContent = text; lab.classList.remove('swap'); }, 120);
  }

  function applyLevel(p) {
    const low = p.target !== null && p.target <= 10;
    p.el.cell.classList.toggle('low', low);
    p.el.slot.classList.toggle('low', low);
    island.classList.toggle('low', ALL.some((q) => q.target !== null && q.target <= 10));
  }

  const isExpanded = () => island.classList.contains('expanded');

  // ---------- incoming data ----------
  function onUsage(payload) {
    const p = S[payload.provider];
    if (!p) return;
    p.payload = payload;
    const good = payload.status === 'ok' ? payload : payload.last || p.latest;
    if (good) p.latest = good;

    p.target = remainingFor(p);
    const stale = payload.status !== 'ok' && p.target !== null;
    p.el.cell.classList.toggle('stale', stale);
    p.el.slot.classList.toggle('stale', stale);
    applyLevel(p);
    setLabel(p, labelText(p), true);

    if (p.target === null) tweenTo(p, 0, 300, 0, easeOutCubic);
    else tweenTo(p, p.target, isExpanded() ? 800 : 1200, 0, easeOutCubic);
  }

  // ---------- hover: decided by the main process from the real cursor position (cannot get stuck) ----------
  function expand() {
    if (isExpanded()) return;
    island.classList.add('expanded');
    island.classList.remove('collapsed');
    // the tile zooms open first, then the rings sweep in from empty (the second one a beat later)
    ALL.forEach((p, i) => {
      p.shown = 0;
      paintRings(p, 0);
      tweenTo(p, p.target === null ? 0 : p.target, cur.sweepMs, cur.gaugeDelay + 60 + i * 120, easeInOutCubic);
    });
    window.island.refresh(); // main throttles this
  }

  function collapse() {
    if (!isExpanded()) return;
    island.classList.remove('expanded');
    island.classList.add('collapsed');
    // the rings keep their value while the gauges fade out, so nothing jumps
    ALL.forEach((p) => {
      if (p.target !== null && Math.abs(p.shown - p.target) > 0.5) tweenTo(p, p.target, 200, 0, easeOutCubic);
    });
  }

  window.island.onHover((hovering) => (hovering ? expand() : collapse()));

  // click: switch both rings between the 5-hour session and the weekly limit
  document.addEventListener('click', () => {
    mode = mode === '5h' ? '7d' : '5h';
    saveMode();
    island.classList.add('tap');
    setTimeout(() => island.classList.remove('tap'), 140);
    ALL.forEach((p) => {
      p.target = remainingFor(p);
      applyLevel(p);
      setLabel(p, labelText(p), true);
      tweenTo(p, p.target === null ? 0 : p.target, 650, 0, easeInOutCubic);
    });
  });

  // shrink big logos once (a huge image on a scaled, transparent window makes it lag)
  function setLogo(img, url, done) {
    const src = new Image();
    src.onload = () => {
      try {
        const k = Math.min(1, 128 / Math.max(src.naturalWidth, src.naturalHeight, 1));
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(src.naturalWidth * k));
        c.height = Math.max(1, Math.round(src.naturalHeight * k));
        c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
        img.onload = done;
        img.src = c.toDataURL('image/png');
      } catch (_) { img.onload = done; img.src = url; }
    };
    src.onerror = () => { img.onload = done; img.src = url; };
    src.src = url;
  }

  // ---------- your logos: claude.webp (top) and gpt.png (below) ----------
  window.island.onLogos((logos) => {
    for (const id of ['claude', 'gpt']) {
      const url = logos && logos[id];
      if (!url) continue;
      const img = $('logo-' + id);
      setLogo(img, url, () => {
        img.hidden = false;
        $('markSvg-' + id).setAttribute('hidden', ''); // the logo replaces the small ring mark (SVG needs the attribute)
        requestAnimationFrame(() => img.classList.add('ready')); // fade in
      });
    }
  });

  // ---------- show / hide from the keyboard shortcut ----------
  window.island.onVisibility((visible) => {
    if (visible) {
      island.classList.remove('boot'); // glide in from the screen edge
    } else {
      collapse();
      island.classList.add('boot'); // glide out to the right
    }
  });

  window.island.onLayout((layout) => {
    ['m-both', 'm-claude', 'm-gpt'].forEach((c) => island.classList.remove(c));
    island.classList.add('m-' + layout);
  });
  window.island.onStyle(applyStyle);
  window.island.onUsage(onUsage);

  // ---------- startup ----------
  applyStyle('glide');
  ALL.forEach((p) => { applyLevel(p); paintRings(p, 0); });
  requestAnimationFrame(() => {
    setTimeout(() => island.classList.remove('boot'), 250); // glide in from the screen edge
  });
})();
