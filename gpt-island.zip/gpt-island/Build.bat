@echo off
setlocal
cd /d "%~dp0"
echo "%CD%" | findstr /r /c:"[&()^%!]" >nul
if not errorlevel 1 (
  echo.
  echo The folder path contains a special character ^& ^( ^) or %% or !
  echo Please move this folder to a simple path such as C:\apps\gpt-island and run this file again.
  pause
  exit /b 1
)
echo Installing ^(first time only^)...
if not exist node_modules call npm install
if not exist node_modules\electron\dist call npm install-scripts approve electron
if not exist node_modules\electron\dist node node_modules\electron\install.js
echo Building the exe...
call npm run build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Read the red error above.
  pause
  exit /b 1
)
echo.
echo Done. Your file is in the "dist" folder.
if exist dist start "" explorer dist
pause
