# GPT Island (Windows)

A small black tile on the **right edge** of your screen. Hover it to see how much usage you have **left**:

- **ChatGPT** (white ring): the 5-hour and weekly **Codex** limit of your ChatGPT plan (ChatGPT has no public meter for normal chat messages).

Click the tile to switch between the 5-hour and the weekly window. **Ctrl + Alt + Shift + G** shows or hides it.

## 1. Logos
Name them `gpt.png` (webp, png, svg, jpg all work) and put them next to `main.js` **before building**, or in
`%APPDATA%\GPT Island\` (the tray item **Open logo folder** opens it), then restart. Without them you get small ring marks.

## 2. Connect your accounts (one time)
- **ChatGPT:** `npm install -g @openai/codex`, run `codex`, choose **Sign in with ChatGPT**.
  Check that `%USERPROFILE%\.codex\auth.json` exists. If it does not, add `cli_auth_credentials_store = "file"` to
  `%USERPROFILE%\.codex\config.toml` and sign in again.

If a ring says SIGN IN later, run `claude` (or `codex`) once.

## 3. Run it
Needs [Node.js](https://nodejs.org) 18+. In this folder:
1. `npm install` (if npm blocks electron: `npm install-scripts approve electron`, then `node node_modules\electron\install.js`).
2. `npm start`, or double-click `GPT Island.vbs` (no window).

## 4. Make an exe or an installer
- **Easiest:** double-click `Build-Installer.bat`, then run the `Setup` exe from `dist\`. It is a one-click installer: no wizard, it installs
  and starts the app. Look at the right edge of the screen (you also get a notification).
- Portable exe instead: `Build.bat` or `npm run build`.
- Symlink error while building: turn on Windows Developer Mode.
- Then tick **Start with Windows** in the tray menu.

## Troubleshooting
- Nothing appears after installing: an old copy may still be running. Quit it from the tray or run
  `taskkill /f /im electron.exe`. Starting the app again while it runs now just brings the island back.
- Tray **Open log** shows what happened (`island.log`). Send it to me if something is wrong.
- Shortcut taken by another app: it automatically falls back to Ctrl+Alt+Shift+U, then I.

## Tray menu
Refresh now, Show / hide, Animation style (Glide, Bouncy, Snappy), Move down / up, Reset position,
Open logo folder, Open log, Start with Windows, Quit.

## Notes
- Both usage endpoints are undocumented and may change. It refreshes every 5 minutes (hover: at most every 90 s) and after wake from sleep.
- Tokens are only read locally and sent to `api.anthropic.com` and `chatgpt.com`.
- Hover is detected from the real cursor position, so it can't get stuck. The ring sweep, count-up and fades are back; pick the feel under **Animation style** in the tray (Glide default).
