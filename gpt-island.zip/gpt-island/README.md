# GPT Island (Windows)

A small black tile on the **right edge** of your screen showing your `gpt.png` logo. Hover it and it opens into a
**white ring** with how much of your ChatGPT plan's **Codex** usage you have left (5-hour or weekly window).
Click switches 5-hour / weekly. **Ctrl + Alt + Shift + G** shows or hides it.

ChatGPT has no public meter for normal chat messages, so the ring shows the Codex limit of your plan.

## Connect ChatGPT (one time)
1. `npm install -g @openai/codex`
2. Run `codex`, choose **Sign in with ChatGPT**, approve in the browser.
3. Check `%USERPROFILE%\.codex\auth.json` exists. If not, add `cli_auth_credentials_store = "file"` to
   `%USERPROFILE%\.codex\config.toml` and sign in again.

## Logo
Put `gpt.png` (or .webp/.svg/.jpg) next to `main.js` or in `%APPDATA%\gpt-island\` and restart.

## Run
- `npm install` once (if npm blocks electron: `npm install-scripts approve electron`, then `node node_modules\electron\install.js`).
- `npm start`, or double-click `GPT Island.vbs` (no window).
- **Exe:** double-click `Build.bat` (or run `npm run build`). The exe appears in `dist\`. Run it, then tick
  **Start with Windows** in the tray menu. If the build fails with a symlink error, enable Windows Developer Mode.

## Tray menu
Refresh now, Show / hide, Open / close style, Move up / down, Reset position, Open logo folder, Start with Windows, Quit.

Defaults: starts 210 px from the top; Claude Island uses Ctrl+Alt+Shift+Y at 100 px, so you can run both together.
