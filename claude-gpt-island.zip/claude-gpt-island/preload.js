const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('island', {
  onUsage: (cb) => ipcRenderer.on('usage', (_e, payload) => cb(payload)),
  onLogos: (cb) => ipcRenderer.on('logos', (_e, logos) => cb(logos)),
  onVisibility: (cb) => ipcRenderer.on('visibility', (_e, visible) => cb(visible)),
  onStyle: (cb) => ipcRenderer.on('style', (_e, name) => cb(name)),
  onHover: (cb) => ipcRenderer.on('hover', (_e, hovering) => cb(hovering))
});
