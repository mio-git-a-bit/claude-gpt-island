# Claude GPT Island (Windows)

A tall black tile pinned to the **right edge** of your screen. Collapsed, it shows `claude.webp` on top and
`gpt.png` under it. Hover it and it opens into two rings that show how much usage you have **left**:

- Top: **Claude**, orange ring (your Claude plan: 5-hour session and weekly limit).
- Bottom: **ChatGPT**, white ring (your ChatGPT plan's **Codex** limits: 5-hour and weekly window).

Click the tile to switch both rings between the 5-hour and the weekly window. Ctrl + Alt + Shift + U shows or hides it.

> What "ChatGPT usage" means here: ChatGPT does not publish a usage meter for normal chat messages. What it does
> expose is the usage limit of your plan's **Codex** (5-hour and weekly windows). That is what the white ring shows.
> It needs your ChatGPT account to be signed in to the Codex CLI (section 2).

---

## Where to put the logos

Name them exactly `claude.webp` and `gpt.png` (`.webp`, `.png`, `.svg`, `.jpg` all work for both) and put them in ONE of these places, then restart the app:

1. Next to `main.js`, for example `C:\apps\claude-gpt-island\`.
2. In `%APPDATA%\claude-gpt-island\`. This also works for the built exe without rebuilding. The tray item **Open logo folder** opens it.

Without the files, small ring marks (orange and white) are shown instead.

---

## 1. Connect Claude (one time)

The app reads the login that **Claude Code** saves on your PC. You need a Claude Pro, Max, Team or Enterprise account.

1. Open **PowerShell** and run `irm https://claude.ai/install.ps1 | iex`
2. Open a **new** PowerShell window and run `claude`. Sign in in the browser and approve. Close it when it says `Login successful`.

## 2. Connect ChatGPT (one time)

The app reads the login that the **Codex CLI** saves on your PC when you sign in with your ChatGPT account.

1. Install the Codex CLI: `npm install -g @openai/codex`
2. Run `codex`, choose **Sign in with ChatGPT**, and approve in the browser. (Some versions also have `codex login`.)
3. Check that this file exists: `%USERPROFILE%\.codex\auth.json`.

**If `auth.json` does not exist:** newer Codex versions can store the login in the Windows Credential Manager instead of a file,
and this app can only read the file. To make Codex use the file, create or edit `%USERPROFILE%\.codex\config.toml` and add:

```
cli_auth_credentials_store = "file"
```

Then sign in to Codex again (step 2).

If the white ring says **SIGN IN** later, run `codex` once so it renews the login. If the orange ring says SIGN IN, run `claude` once.

---

## 3. Install the app

You need [Node.js](https://nodejs.org) 18 or newer (LTS is fine).

1. Unzip into a permanent folder, for example `C:\apps\claude-gpt-island`.
2. If PowerShell says running scripts is disabled, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`
3. In that folder run `npm install` (one time).
4. If npm says an install script for electron is not approved, run `npm install-scripts approve electron`, then `node node_modules\electron\install.js`.
5. Run `npm start`, or double-click `Claude GPT Island.vbs` to start it with no window (it keeps running after you close PowerShell).

**Recommended for daily use (a real exe):** run `npm run build`, then run the exe in `dist\`, then tick **Start with Windows** in the tray menu.
If the build fails with a symbolic link error, turn on Windows Developer Mode (Settings, System, For developers).

## 4. Update it later

1. Quit it from the tray icon.
2. Copy the new files over the old folder (keep `node_modules`, `claude.webp` and `gpt.png`).
3. Run `npm install` only if `package.json` changed.
4. Start it again, or rebuild the exe with `npm run build`.

---

## Tray menu

Refresh now, Show / hide, Open / close style (Quick zoom, Smooth zoom, Instant), Move up, Move down, Reset position,
Open logo folder, Start with Windows, Quit.

## Notes

- Usage is shown directly (no ring sweep, no fading). Hover is detected from the real cursor position, so it cannot get stuck open.
- Both usage endpoints are undocumented and could change or break after an update on their side.
- It refreshes every 5 minutes, and hovering can trigger a refresh at most every 90 seconds. Tray "Refresh now" always refreshes.
- Your tokens are only read locally and sent to `api.anthropic.com` (Claude) and `chatgpt.com` (ChatGPT). Nothing else leaves your machine.
- You can run this together with the single-ring Claude Island. They use different shortcuts (this one: Ctrl+Alt+Shift+U, Claude Island: Ctrl+Alt+Shift+Y) and this one starts lower on the screen (280 px from the top) so the two tiles do not overlap. Use Move up / Move down in the tray to change it.
