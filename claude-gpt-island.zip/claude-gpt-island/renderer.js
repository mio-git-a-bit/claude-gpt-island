(function () {
  const $ = (id) => document.getElementById(id);
  const island = $('island');
  const C_GAUGE = 2 * Math.PI * 40; // gauge ring, r=40
  const C_MARK = 2 * Math.PI * 38;  // collapsed mark ring, r=38

  // ---------- zoom styles (switch them from the tray menu). Only the size of the tile animates. ----------
  const STYLES = {
    quick:   { openMs: 150, closeMs: 130, ease: 'cubic-bezier(0.2, 0, 0, 1)' },
    smooth:  { openMs: 300, closeMs: 240, ease: 'cubic-bezier(0.22, 1, 0.36, 1)' },
    instant: { openMs: 0,   closeMs: 0,   ease: 'linear' }
  };

  function applyStyle(name) {
    const st = STYLES[name] || STYLES.quick;
    const s = island.style;
    s.setProperty('--dur-open', st.openMs + 'ms');
    s.setProperty('--dur-close', st.closeMs + 'ms');
    s.setProperty('--ease', st.ease);
  }

  // ---------- one state object per service ----------
  const makeState = (id) => ({
    id,
    target: null,   // remaining % for the selected window, or null when unknown
    latest: null,   // last good usage payload
    payload: null,  // last payload of any kind (ok or error)
    el: {
      gauge: $('gaugeFill-' + id),
      mark: $('markFill-' + id),
      num: $('num-' + id),
      lab: $('lab-' + id),
      cell: $('cell-' + id),
      slot: $('markSvg-' + id).parentElement
    }
  });
  const S = { claude: makeState('claude'), gpt: makeState('gpt') };
  const ALL = [S.claude, S.gpt];

  let mode = loadMode();  // '5h' | '7d' (shared by both rings)

  function loadMode() {
    try { return localStorage.getItem('mode') === '7d' ? '7d' : '5h'; } catch (_) { return '5h'; }
  }
  function saveMode() {
    try { localStorage.setItem('mode', mode); } catch (_) {}
  }

  // ---------- drawing: everything is drawn straight at its final value, no sweeping or counting ----------
  const clamp = (n, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, n));

  function paint(p) {
    const v = p.target === null ? 0 : p.target;
    p.el.gauge.style.strokeDashoffset = C_GAUGE * (1 - v / 100);
    p.el.mark.style.strokeDashoffset = C_MARK * (1 - v / 100);
    const visible = v > 0.4 ? '1' : '0'; // avoid a round-cap dot at 0%
    p.el.gauge.style.opacity = visible;
    p.el.mark.style.opacity = visible;
    p.el.num.textContent = p.target === null ? '--' : String(Math.round(v));
    p.el.lab.textContent = labelText(p);
    const low = p.target !== null && p.target <= 10;
    p.el.cell.classList.toggle('low', low);
    p.el.slot.classList.toggle('low', low);
  }

  function remainingFor(p) {
    const data = p.latest && p.latest.data;
    if (!data) return null;
    const win = mode === '5h' ? data.five_hour : data.seven_day;
    if (!win || typeof win.utilization !== 'number') return null;
    return clamp(100 - Math.round(win.utilization));
  }

  function labelText(p) {
    const pl = p.payload;
    if (p.target === null && pl && pl.status && pl.status !== 'ok') {
      return { auth: 'SIGN IN', offline: 'OFFLINE', rate: 'RETRY' }[pl.status] || 'ERROR';
    }
    return (mode === '5h' ? '5H' : '7D') + ' LEFT';
  }

  // ---------- incoming data ----------
  function onUsage(payload) {
    const p = S[payload.provider];
    if (!p) return;
    p.payload = payload;
    const good = payload.status === 'ok' ? payload : payload.last || p.latest;
    if (good) p.latest = good;

    p.target = remainingFor(p);
    const stale = payload.status !== 'ok' && p.target !== null;
    p.el.cell.classList.toggle('stale', stale);
    p.el.slot.classList.toggle('stale', stale);
    paint(p);
  }

  // ---------- hover: decided by the main process from the real cursor position ----------
  window.island.onHover((hovering) => {
    island.classList.toggle('expanded', hovering);
    island.classList.toggle('collapsed', !hovering);
  });

  // click: switch both rings between the 5-hour session and the weekly limit
  document.addEventListener('click', () => {
    mode = mode === '5h' ? '7d' : '5h';
    saveMode();
    ALL.forEach((p) => {
      p.target = remainingFor(p);
      paint(p);
    });
  });

  // ---------- your logos: claude.webp (top) and gpt.png (below) ----------
  window.island.onLogos((logos) => {
    for (const id of ['claude', 'gpt']) {
      const url = logos && logos[id];
      if (!url) continue;
      const img = $('logo-' + id);
      img.onload = () => {
        img.hidden = false;
        $('markSvg-' + id).setAttribute('hidden', ''); // the logo replaces the small ring mark (SVG needs the attribute)
      };
      img.src = url;
    }
  });

  // ---------- show / hide from the keyboard shortcut ----------
  window.island.onVisibility((visible) => {
    island.classList.toggle('boot', !visible); // slides out to / in from the screen edge
    if (!visible) {
      island.classList.remove('expanded');
      island.classList.add('collapsed');
    }
  });

  window.island.onStyle(applyStyle);
  window.island.onUsage(onUsage);

  // ---------- startup ----------
  applyStyle('quick');
  ALL.forEach(paint);
  requestAnimationFrame(() => {
    setTimeout(() => island.classList.remove('boot'), 250); // slide in from the screen edge
  });
})();
