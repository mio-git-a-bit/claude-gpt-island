const { app, BrowserWindow, Tray, Menu, ipcMain, screen, nativeImage, shell, globalShortcut } = require('electron');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

// ---------- settings ----------
const POLL_MS = 5 * 60 * 1000;          // the usage endpoints rate-limit, so don't poll faster
const HOVER_REFRESH_MIN_MS = 90 * 1000; // hovering may trigger a refresh, but never more often than this
const WIN_W = 150;
const WIN_H = 250;
const TILE_W = 58, TILE_H = 126;        // collapsed tile size, also used to keep it on screen
const CARD_W = 98, CARD_H = 214;        // expanded card size
const HOVER_POLL_MS = 40;               // how often the real cursor position is checked
const HOVER_SLACK = 3;                  // forgiving margin so the edge of the card does not flicker
const DEFAULT_OFFSET_Y = 280;           // distance from the top of the work area
const NUDGE = 20;                       // tray "Move up / Move down" step
const SHORTCUT = 'CommandOrControl+Alt+Shift+U';

let settings = { launchAtLogin: false, offsetY: DEFAULT_OFFSET_Y, anim: 'quick' };
let visible = true;
let shortcutOk = false;
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function loadSettings() {
  try {
    settings = { ...settings, ...JSON.parse(fs.readFileSync(settingsFile(), 'utf8')) };
  } catch (_) {}
}
function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch (_) {}
}

// ---------- optional logos: claude.webp (top) and gpt.png (below) ----------
// Put them in the app folder or in %APPDATA%\claude-gpt-island\
function findImage(baseName) {
  const exts = ['webp', 'png', 'svg', 'jpg', 'jpeg'];
  const mime = { png: 'image/png', svg: 'image/svg+xml', webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
  const dirs = [app.getPath('userData'), __dirname];
  for (const dir of dirs) {
    for (const ext of exts) {
      try {
        const file = path.join(dir, `${baseName}.${ext}`);
        const stat = fs.statSync(file);
        if (!stat.isFile() || stat.size > 2 * 1024 * 1024) continue;
        return `data:${mime[ext]};base64,${fs.readFileSync(file).toString('base64')}`;
      } catch (_) {}
    }
  }
  return null;
}
const findLogos = () => ({ claude: findImage('claude'), gpt: findImage('gpt') });

// ---------- shared HTTPS helper ----------
function getJson(hostname, reqPath, headers) {
  return new Promise((resolve) => {
    const req = https.request(
      { hostname, path: reqPath, method: 'GET', timeout: 15000, headers },
      (res) => {
        let body = '';
        res.on('data', (c) => (body += c));
        res.on('end', () => resolve({ code: res.statusCode, body }));
      }
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', () => resolve({ code: 0, body: '' }));
    req.end();
  });
}

function statusFromCode(code, authMsg) {
  if (code === 0) return { status: 'offline', message: 'Offline, will retry.' };
  if (code === 401 || code === 403) return { status: 'auth', message: authMsg };
  if (code === 429) return { status: 'rate', message: 'Rate limited, will retry shortly.' };
  return { status: 'error', message: `Request failed (${code}).` };
}

// ---------- Claude (login saved by Claude Code) ----------
function claudeCredentialPaths() {
  const paths = [];
  if (process.env.CLAUDE_CONFIG_DIR) paths.push(path.join(process.env.CLAUDE_CONFIG_DIR, '.credentials.json'));
  paths.push(path.join(os.homedir(), '.claude', '.credentials.json'));
  return paths;
}

function readClaudeToken() {
  if (process.env.CLAUDE_CODE_OAUTH_TOKEN) return { token: process.env.CLAUDE_CODE_OAUTH_TOKEN };
  for (const p of claudeCredentialPaths()) {
    try {
      const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
      const oauth = raw.claudeAiOauth || raw;
      if (oauth && oauth.accessToken) {
        return { token: oauth.accessToken, expiresAt: oauth.expiresAt, plan: oauth.subscriptionType };
      }
    } catch (_) {}
  }
  return null;
}

async function fetchClaude() {
  const cred = readClaudeToken();
  if (!cred) return { status: 'auth', message: 'Not signed in to Claude. Run "claude" once in a terminal.' };
  if (cred.expiresAt && Number(cred.expiresAt) < Date.now()) {
    return { status: 'auth', message: 'Claude login expired. Open Claude Code once to refresh it.' };
  }
  const res = await getJson('api.anthropic.com', '/api/oauth/usage', {
    Authorization: `Bearer ${cred.token}`,
    'anthropic-beta': 'oauth-2025-04-20',
    Accept: 'application/json',
    'User-Agent': 'claude-gpt-island/1.0'
  });
  if (res.code === 200) {
    try {
      return { status: 'ok', data: JSON.parse(res.body), plan: cred.plan, fetchedAt: Date.now() };
    } catch (_) {
      return { status: 'error', message: 'Unexpected response from Anthropic.' };
    }
  }
  return statusFromCode(res.code, 'Claude login expired. Open Claude Code once to refresh it.');
}

// ---------- ChatGPT (Codex usage limits, login saved by the Codex CLI) ----------
function codexAuthPath() {
  const home = process.env.CODEX_HOME || path.join(os.homedir(), '.codex');
  return path.join(home, 'auth.json');
}

function decodeJwt(token) {
  try {
    const part = String(token).split('.')[1];
    return JSON.parse(Buffer.from(part.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
  } catch (_) {
    return null;
  }
}

function readCodexToken() {
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(codexAuthPath(), 'utf8'));
  } catch (_) {
    return { error: 'missing' };
  }
  const t = raw.tokens || {};
  if (!t.access_token) return { error: 'nologin' }; // for example an API-key login, which has no ChatGPT limits
  const claims = decodeJwt(t.access_token) || {};
  const idClaims = decodeJwt(t.id_token) || {};
  const accountId =
    t.account_id ||
    (claims['https://api.openai.com/auth'] || {}).chatgpt_account_id ||
    (idClaims['https://api.openai.com/auth'] || {}).chatgpt_account_id ||
    null;
  return { token: t.access_token, accountId, expMs: claims.exp ? claims.exp * 1000 : null };
}

// turn the ChatGPT payload into the same shape the Claude one has: five_hour / seven_day with utilization
function normalizeCodex(data) {
  const rl = (data && data.rate_limit) || {};
  const out = {};
  const toWin = (w) => ({
    utilization: Number(w.used_percent),
    resets_at: w.reset_at ? new Date(Number(w.reset_at) * 1000).toISOString() : null
  });
  const list = [rl.primary_window, rl.secondary_window].filter((w) => w && typeof w.used_percent === 'number');
  for (const w of list) {
    const secs = Number(w.limit_window_seconds);
    // short window (about 5 hours) vs long window (about 7 days), matched by duration
    const isShort = secs ? secs <= 36 * 3600 : w === rl.primary_window;
    if (isShort && !out.five_hour) out.five_hour = toWin(w);
    else if (!out.seven_day) out.seven_day = toWin(w);
  }
  return out;
}

async function fetchGpt() {
  const cred = readCodexToken();
  if (cred.error === 'missing') {
    return { status: 'auth', message: 'No Codex login found. Sign in to Codex with ChatGPT (see README).' };
  }
  if (cred.error) {
    return { status: 'auth', message: 'Codex is not signed in with a ChatGPT account.' };
  }
  if (cred.expMs && cred.expMs < Date.now()) {
    return { status: 'auth', message: 'ChatGPT login expired. Run "codex" once to refresh it.' };
  }
  const headers = {
    Authorization: `Bearer ${cred.token}`,
    Accept: 'application/json',
    'User-Agent': 'claude-gpt-island/1.0'
  };
  if (cred.accountId) headers['ChatGPT-Account-Id'] = cred.accountId;
  const res = await getJson('chatgpt.com', '/backend-api/wham/usage', headers);
  if (res.code === 200) {
    try {
      const raw = JSON.parse(res.body);
      return { status: 'ok', data: normalizeCodex(raw), plan: raw.plan_type, fetchedAt: Date.now() };
    } catch (_) {
      return { status: 'error', message: 'Unexpected response from ChatGPT.' };
    }
  }
  return statusFromCode(res.code, 'ChatGPT login expired. Run "codex" once to refresh it.');
}

// ---------- window ----------
let win = null;
let tray = null;
const lastGood = { claude: null, gpt: null };
let lastFetch = 0;
let timer = null;

function placeWindow() {
  if (!win) return;
  // Flush against the right edge of the primary display, offsetY below the top of the work area.
  const wa = screen.getPrimaryDisplay().workArea;
  const maxY = Math.max(0, wa.height - TILE_H - 12);
  const off = Math.min(Math.max(Number(settings.offsetY) || 0, 0), maxY);
  win.setBounds({ x: wa.x + wa.width - WIN_W, y: wa.y + off, width: WIN_W, height: WIN_H });
}

function nudge(dy) {
  settings.offsetY = (Number(settings.offsetY) || 0) + dy;
  saveSettings();
  placeWindow();
}

// Show or hide the island; the renderer plays the slide animation and main hides the window afterwards.
function setVisible(v) {
  if (!win || win.isDestroyed() || v === visible) return;
  visible = v;
  if (v) {
    win.setAlwaysOnTop(true, 'screen-saver');
    win.showInactive();
    win.webContents.send('visibility', true);
    refresh(false);
  } else {
    resetHover();
    win.webContents.send('visibility', false);
    setTimeout(() => {
      if (!visible && win && !win.isDestroyed()) win.hide();
    }, 600);
  }
}
const toggleVisible = () => setVisible(!visible);

// ---------- hover: decided here from the real cursor position, so it can never get stuck ----------
let hovering = false;
let leaveCount = 0;
let hoverTimer = null;

function setHover(v) {
  if (v === hovering) return;
  hovering = v;
  if (!win || win.isDestroyed()) return;
  // let clicks through everywhere except while the cursor is over the tile
  win.setIgnoreMouseEvents(!v, { forward: true });
  win.webContents.send('hover', v);
}

function resetHover() {
  leaveCount = 0;
  setHover(false);
}

function pollCursor() {
  if (!win || win.isDestroyed() || !visible) return;
  const p = screen.getCursorScreenPoint();
  const b = win.getBounds();
  const lx = p.x - b.x;
  const ly = p.y - b.y;
  const w = hovering ? CARD_W + HOVER_SLACK : TILE_W;
  const h = hovering ? CARD_H + HOVER_SLACK : TILE_H;
  const inside = lx >= b.width - w && lx <= b.width + 2 && ly >= -2 && ly <= h;
  if (inside) {
    leaveCount = 0;
    setHover(true);
  } else if (hovering) {
    leaveCount += 1;
    if (leaveCount >= 3) { // outside for about 120 ms in a row
      leaveCount = 0;
      setHover(false);
    }
  }
}

function createWindow() {
  win = new BrowserWindow({
    width: WIN_W,
    height: WIN_H,
    frame: false,
    transparent: true,
    resizable: false,
    movable: false,
    maximizable: false,
    minimizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    hasShadow: false,
    focusable: false,
    alwaysOnTop: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.setAlwaysOnTop(true, 'screen-saver');
  win.setVisibleOnAllWorkspaces(true);
  win.setIgnoreMouseEvents(true, { forward: true });
  placeWindow();
  win.loadFile('index.html');
  win.once('ready-to-show', () => win.showInactive());
  win.webContents.on('did-finish-load', () => {
    resetHover();
    win.webContents.send('style', settings.anim);
    win.webContents.send('logos', findLogos());
    for (const provider of ['claude', 'gpt']) {
      if (lastGood[provider]) win.webContents.send('usage', { ...lastGood[provider], provider });
    }
    refresh(true);
  });
}

function push(provider, result) {
  if (result.status === 'ok') lastGood[provider] = result;
  if (win && !win.isDestroyed()) {
    win.webContents.send(
      'usage',
      result.status === 'ok' ? { ...result, provider } : { ...result, provider, last: lastGood[provider] }
    );
  }
}

async function refresh(force = false) {
  const now = Date.now();
  if (!force && now - lastFetch < HOVER_REFRESH_MIN_MS) return;
  lastFetch = now;
  const [claude, gpt] = await Promise.all([fetchClaude(), fetchGpt()]);
  push('claude', claude);
  push('gpt', gpt);
}

// Register (or remove) the app to start with Windows. Works for `npm start`, the portable exe and the installer.
function applyLoginItem(enabled) {
  const exe = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
  const args = app.isPackaged ? [] : [app.getAppPath()];
  app.setLoginItemSettings({ openAtLogin: enabled, path: exe, args });
}

function buildTray() {
  const iconPath = path.join(__dirname, 'icon.png');
  let img = nativeImage.createFromPath(iconPath);
  if (!img.isEmpty()) img = img.resize({ width: 16, height: 16 });
  tray = new Tray(img);
  tray.setToolTip('Claude GPT Island');
  const menu = Menu.buildFromTemplate([
    { label: 'Refresh now', click: () => refresh(true) },
    {
      label: shortcutOk ? 'Show / hide island  (Ctrl+Alt+Shift+U)' : 'Show / hide island  (shortcut unavailable)',
      click: toggleVisible
    },
    {
      label: 'Open / close style',
      submenu: [
        ['quick', 'Quick zoom'],
        ['smooth', 'Smooth zoom'],
        ['instant', 'Instant (no animation)']
      ].map(([id, label]) => ({
        label,
        type: 'radio',
        checked: settings.anim === id,
        click: () => {
          settings.anim = id;
          saveSettings();
          if (win && !win.isDestroyed()) win.webContents.send('style', id);
        }
      }))
    },
    { label: 'Move down', click: () => nudge(NUDGE) },
    { label: 'Move up', click: () => nudge(-NUDGE) },
    {
      label: 'Reset position',
      click: () => {
        settings.offsetY = DEFAULT_OFFSET_Y;
        saveSettings();
        placeWindow();
      }
    },
    { type: 'separator' },
    {
      label: 'Open logo folder',
      click: () => {
        const dir = app.getPath('userData');
        try { fs.mkdirSync(dir, { recursive: true }); } catch (_) {}
        shell.openPath(dir);
      }
    },
    { type: 'separator' },
    {
      label: 'Start with Windows',
      type: 'checkbox',
      checked: settings.launchAtLogin,
      click: (item) => {
        settings.launchAtLogin = item.checked;
        saveSettings();
        applyLoginItem(item.checked);
      }
    },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]);
  tray.setContextMenu(menu);
  tray.on('click', () => refresh(true));
}

// ---------- app lifecycle ----------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.whenReady().then(() => {
    loadSettings();
    if (settings.launchAtLogin) applyLoginItem(true); // keep the startup entry pointing at the current exe
    shortcutOk = globalShortcut.register(SHORTCUT, toggleVisible);
    createWindow();
    buildTray();
    timer = setInterval(() => refresh(true), POLL_MS);
    hoverTimer = setInterval(pollCursor, HOVER_POLL_MS);

    screen.on('display-metrics-changed', placeWindow);
    screen.on('display-added', placeWindow);
    screen.on('display-removed', placeWindow);

    ipcMain.on('refresh', () => refresh(false));
  });

  app.on('window-all-closed', () => {});
  app.on('before-quit', () => { if (timer) clearInterval(timer); if (hoverTimer) clearInterval(hoverTimer); });
  app.on('will-quit', () => globalShortcut.unregisterAll());
}
